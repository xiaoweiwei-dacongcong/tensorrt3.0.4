#
# Copyright 1993-2017 NVIDIA Corporation.  All rights reserved.
#
# NOTICE TO LICENSEE:
#
# This source code and/or documentation ("Licensed Deliverables") are
# subject to NVIDIA intellectual property rights under U.S. and
# international Copyright laws.
#
# These Licensed Deliverables contained herein is PROPRIETARY and
# CONFIDENTIAL to NVIDIA and is being provided under the terms and
# conditions of a form of NVIDIA software license agreement by and
# between NVIDIA and Licensee ("License Agreement") or electronically
# accepted by Licensee.  Notwithstanding any terms or conditions to
# the contrary in the License Agreement, reproduction or disclosure
# of the Licensed Deliverables to any third party without the express
# written consent of NVIDIA is prohibited.
#
# NOTWITHSTANDING ANY TERMS OR CONDITIONS TO THE CONTRARY IN THE
# LICENSE AGREEMENT, NVIDIA MAKES NO REPRESENTATION ABOUT THE
# SUITABILITY OF THESE LICENSED DELIVERABLES FOR ANY PURPOSE.  IT IS
# PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY OF ANY KIND.
# NVIDIA DISCLAIMS ALL WARRANTIES WITH REGARD TO THESE LICENSED
# DELIVERABLES, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY,
# NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
# NOTWITHSTANDING ANY TERMS OR CONDITIONS TO THE CONTRARY IN THE
# LICENSE AGREEMENT, IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY
# SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, OR ANY
# DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
# WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
# ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
# OF THESE LICENSED DELIVERABLES.
#
# U.S. Government End Users.  These Licensed Deliverables are a
# "commercial item" as that term is defined at 48 C.F.R. 2.101 (OCT
# 1995), consisting of "commercial computer software" and "commercial
# computer software documentation" as such terms are used in 48
# C.F.R. 12.212 (SEPT 1995) and is provided to the U.S. Government
# only as a commercial end item.  Consistent with 48 C.F.R.12.212 and
# 48 C.F.R. 227.7202-1 through 227.7202-4 (JUNE 1995), all
# U.S. Government End Users acquire the Licensed Deliverables with
# only those rights set forth herein.
#
# Any use of the Licensed Deliverables in individual and commercial
# software must include, in the user documentation and internal
# comments to the code, the above Disclaimer and U.S. Government End
# Users Notice.
#

#!/usr/bin/python
import os
import sys
import argparse

def shape(s):
    try:
        C, H, W = map(int, s.split('x'))
        return C, H, W
    except:
        raise argparse.ArgumentTypeError("Shape must be CxHxW, e.g. 1x28x28")

PARSER = argparse.ArgumentParser(description="Command line interface for common TensorRT tasks")

PARSER.add_argument(      '--frozenmodel',   help='Tensorflow frozen protobuf file')
PARSER.add_argument(      '--uff',           help='Universal Framework Format file')
PARSER.add_argument(      '--deployfile',    help='Caffe deploy file')
PARSER.add_argument(      '--outlayers',     help="Output blob name (can be specified multiple times)", nargs='+', required=True, type=str)
PARSER.add_argument(      '--modelfile',     help="Caffe model file (default = no model, random weights used)", default=None)
PARSER.add_argument(      '--inlayers',      help="Input blob name (can be specified multiple times)", nargs='+', default=["data"] )
PARSER.add_argument(      '--inshape',       help="Shape of input layer (CxHxW)", nargs='+', type=shape)
PARSER.add_argument('-b', '--batchsize',     help="Set batch size", type=int, default=1)
PARSER.add_argument('-d', '--device',        help="Set cuda device to N", type=int, default=0)
PARSER.add_argument('-i', '--iterations',    help="Run N iterations", type=int, default=10)
PARSER.add_argument('-a', '--avgruns',       help="Set avgRuns to N - perf is measured as an average of avgRuns", type=int, default=10)
PARSER.add_argument('-w', '--workspacesize', help="Set workspace size in megabytes", type=int, default=16)
PARSER.add_argument(      '--half',          help="Run in paired fp16 mode", action='store_true')
PARSER.add_argument(      '--int8',          help="Run in int8 mode", action='store_true')
PARSER.add_argument('-v', '--verbose',       help="Verbose output")
PARSER.add_argument(      '--hosttime',      help="Measure host time rather than GPU time", action='store_true')
PARSER.add_argument(      '--calibration',   help="Read INT8 calibration cache file")
PARSER.add_argument('-e', '--engine',        help="Generate an engine file (if a Caffe File is provided) or run from existing engine file")

ARGS = PARSER.parse_args()

os.environ["CUDA_DEVICE"] = str(ARGS.device)

import random
import numpy as np
import time

try:
    from PIL import Image
    import pycuda.driver as cuda
    import pycuda.autoinit
except ImportError as err:
    sys.stderr.write("""ERROR: failed to import module ({})
Please make sure you have pycuda and the example dependencies installed.
https://wiki.tiker.net/PyCuda/Installation/Linux
pip(3) install tensorrt[examples]
""".format(err))
    exit(1)

try:
    import tensorrt as trt
    from tensorrt import parsers
except ImportError as err:
    sys.stderr.write("""ERROR: failed to import module ({})
Please make sure you have the TensorRT Library installed
and accessible in your LD_LIBRARY_PATH
""".format(err))
    exit(1)

G_LOGGER = trt.infer.ConsoleLogger(trt.infer.LogSeverity.ERROR)

def create_memory(engine, name, arr_index, buf, binding_type):
    if ARGS.frozenmodel and binding_type == "out":
        name = name + '_' + str(arr_index)
    binding_idx = engine.get_binding_index(name)
    if binding_idx == -1:
        raise AttributeError("Not a valid binding")
    print("Binding: name={}, bindingIndex={}".format(name, str(binding_idx)))
    dims = engine.get_binding_dimensions(binding_idx).to_DimsCHW()
    eltCount = dims.C() * dims.H() * dims.W() * ARGS.batchsize

    h_mem = np.random.uniform(0.0, 255.0, eltCount).astype(np.dtype('f4'))

    d_mem = cuda.mem_alloc(len(h_mem) * h_mem.itemsize)
    cuda.memcpy_htod(d_mem, h_mem)
    buf.insert(binding_idx, int(d_mem))
    return buf


def infer(engine):
    context =  engine.create_execution_context()
    bindings = []
    for i in range(len(ARGS.inlayers)):
        create_memory(engine, ARGS.inlayers[i], i, bindings, "in")
    for o in range(len(ARGS.outlayers)):
        create_memory(engine, ARGS.outlayers[o], o, bindings, "out")

    stream = cuda.Stream()
    start = cuda.Event()
    stop = cuda.Event()

    for j in range(ARGS.iterations):
        total = 0.0
        ms = 0.0
        for i in range(ARGS.avgruns):
            if ARGS.hosttime:
                h_start = time.perf_counter()
                context.execute(ARGS.batchsize, bindings)
                h_stop = time.perf_counter()
                ms = h_stop - h_start
            else:
                start.record(stream)
                context.enqueue(ARGS.batchsize, bindings, stream.handle, None)
                stop.record(stream)
                stream.synchronize()
                ms = start.time_till(stop)
            total += ms
        total /= ARGS.avgruns
        print("Average over {} runs is {}ms".format(ARGS.avgruns, total * 1000 if ARGS.hosttime else total))

    return

def create_engine():
    datatype = trt.infer.DataType.FLOAT
    if ARGS.half and ARGS.int8:
        raise AttributeError("Specified both Half Precision and Int8, please pick one")
    elif ARGS.half:
        datatype = trt.infer.DataType.HALF
    elif ARGS.int8:
        datatype = trt.infer.DataType.INT8

    if ARGS.deployfile:
        engine = trt.utils.caffe_to_trt_engine(G_LOGGER,
            ARGS.deployfile,
            ARGS.modelfile,
            ARGS.batchsize,
            ARGS.workspacesize,
            ARGS.outlayers,
            datatype)

        assert(engine)
        if ARGS.engine:
            trt.utils.write_engine_to_file(ARGS.engine, engine.serialize())

        return engine

    elif ARGS.frozenmodel:
        try:
            import uff
        except ImportError:
            raise ImportError("""Please install the UFF Toolkit""")

        if not ARGS.inlayers or not ARGS.inshape:
            raise AttributeError("Need input layer and shape to parse tensorflow models")
        uffstream = uff.from_tensorflow_frozen_model(ARGS.frozenmodel, o, input_node=ARGS.inlayers)
        parser = parsers.uffparser.create_uff_parser()
        for i in range(len(ARGS.inlayers)):
            parser.register_input(ARGS.inlayers[i], ARGS.inshape[i], 0)
        for o in ARGS.outlayers:
            parser.register_output(o)

        engine = trt.utils.uff_to_trt_engine(G_LOGGER,
            uffstream,
            parser,
            ARGS.batchsize,
            ARGS.workspacesize,
            datatype)

        parser.destroy()

        assert(engine)
        if ARGS.engine:
            trt.utils.write_engine_to_file(ARGS.engine, engine.serialize())

        return engine

    elif ARGS.uff:
        if not ARGS.inlayers or not ARGS.inshape:
            raise AttributeError("Need input layer and shape to parse tensorflow models")
        parser = parsers.uffparser.create_uff_parser()
        for i in range(len(ARGS.inlayers)):
            parser.register_input(ARGS.inlayers[i], ARGS.inshape[i])
        for o in ARGS.outlayers:
            parser.register_output(o)

        engine = trt.utils.uff_file_to_trt_engine(G_LOGGER,
            ARGS.uff,
            parser,
            ARGS.batchsize,
            ARGS.workspacesize,
            datatype)

        assert(engine)
        if ARGS.engine:
            trt.utils.write_engine_to_file(ARGS.engine, engine.serialize())

        return engine

    elif ARGS.engine:
        engine = trt.utils.load_engine(G_LOGGER, ARGS.engine)
        assert(engine)
        return engine
    raise AttributeError("Did not supply an engine file or a caffe model")

def main():
    path = os.path.dirname(os.path.realpath(__file__))
    if not ARGS.outlayers:
        raise AttributeError("Need to specify output layers")
    engine = create_engine()
    infer(engine)
    engine.destroy()

if __name__ == "__main__":
    main()

