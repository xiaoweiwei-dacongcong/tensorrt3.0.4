"""
conversion_helpers.py

Main script for doing uff conversions from
different frameworks.
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from .converter_functions import *  # noqa
from .converter import TensorFlowToUFFConverter as tf2uff
from .proto import GraphDef

import numpy as np
import uff.model as uff


def from_tensorflow(graphdef, output_nodes, **kwargs):
    """
    Helper function for calling the conversion
    from TensorFlow
    """
    quiet = False
    input_node = []
    text = False
    list_nodes = False
    output_filename = None
    for k, v in kwargs.items():
        if k == "quiet":
            quiet = v
        elif k == "input_node":
            input_node = v
        elif k == "text":
            text = v
        elif k == "list_nodes":
            list_nodes = v
        elif k == "output_filename":
            output_filename = v

    if list_nodes:
        for i, node in enumerate(graphdef.node):
            print('%i %s: "%s"' % (i + 1, node.op, node.name))
        return

    for i, name in enumerate(output_nodes):
        output_nodes[i] = tf2uff.convert_node_name_or_index_to_name(
            name, graphdef.node)
        if not quiet:
            print("Using output node", output_nodes[i])

    input_replacements = {}
    for i, name_data in enumerate(input_node):
        name, new_name, dtype, shape = name_data.split(',', 3)
        name = tf2uff.convert_node_name_or_index_to_name(name, graphdef.node)
        if new_name == '':
            new_name = name
        dtype = np.dtype(dtype)
        shape = [int(x) for x in shape.split(',')]
        input_replacements[name] = (new_name, dtype, shape)
        if not quiet:
            print("Using input node", name)

    if not quiet:
        print("Converting to UFF graph")

    uff_metagraph = uff.MetaGraph()
    tf2uff.add_custom_descriptors(uff_metagraph)
    uff_graph = tf2uff.convert_tf2uff_graph(
        graphdef,
        uff_metagraph,
        output_nodes=output_nodes,
        input_replacements=input_replacements,
        name="main")

    uff_metagraph_proto = uff_metagraph.to_uff()
    if not quiet:
        print('No. nodes:', len(uff_graph.nodes))

    if output_filename:
        with open(output_filename, 'wb') as f:
            f.write(uff_metagraph_proto.SerializeToString())
        if not quiet:
            print("UFF Output written to", output_filename)
        if text:  # ASK: Would you want to return the prototxt?
            if not output_filename:
                raise ValueError(
                    "Requested prototxt but did not provide file path")
            output_filename_txt = output_filename + '.pbtxt'
            with open(output_filename_txt, 'w') as f:
                f.write(str(uff_metagraph.to_uff(debug=True)))
            if not quiet:
                print("UFF Text Output written to", output_filename_txt)
    else:
        return uff_metagraph_proto.SerializeToString()


def from_tensorflow_frozen_model(frozen_file, output_nodes, **kwargs):
    graphdef = GraphDef()
    graphdef.ParseFromString(open(frozen_file, "rb").read())

    return from_tensorflow(graphdef, output_nodes, **kwargs)
